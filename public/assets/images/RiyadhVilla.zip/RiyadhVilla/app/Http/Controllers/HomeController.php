<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Status;
use App\Models\Department;
use Carbon\Carbon;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $data['total_employees'] = User::where('status',0)->where('user_type','Employee')->count();
        $data['total_departments'] = Department::count();
        $data['total_present'] = Status::where('date', date('Y-m-d'))->count();
        $data['total_absent'] = $data['total_employees'] - $data['total_present'];
        $data['new_users'] = User::where('status',0)->get();
        
        $total_present_emp = Status::where('date', date('Y-m-d'))->get();
        $present_id = array();
        $i=0;
        foreach($total_present_emp as $row)
        {
            $present_id[$i] = $row->user_id;
            $i++;
        }
        
        $data['present_employees'] = User::where('status',0)->whereIn('id',$present_id)->get();
        
        $total_emp = User::where('status',0)->where('user_type','Employee')->get();
        $total_emp_id = array();
        $i=0;
        foreach($total_emp as $row)
        {
            $total_emp_id[$i] = $row->id;
            $i++;
        }
        
        $data['total_absent_emp'] = User::where('status',0)->whereIn('id',$total_emp_id)->whereNotIn('id',$present_id)->groupBy('id')->get();
        
        for ($i = 0; $i <= 5; $i++) 
        {
            $monthly_attendance[] = Status::whereMonth('date',date("m", strtotime( date( 'Y-m-01' )." -$i months")))->count();
        }
        
        for ($j=5,$m=0; $j>=0,$m<=5; $j--,$m++) 
        {
            $result1[$m]['values'] = $monthly_attendance[$j]; 
            $result1[$m]['text'] = date("F", strtotime( date( 'Y-m-01' )." -$j months"));
        }
    
        $data['monthly_attendance'] = json_encode($result1);
        
        $date_array = array();
        $absent_count = array();

        $i = 0;
        while ($i < 7) {
            $today = Carbon::today();
            array_push( $date_array, $today->subDays($i)->format('d-m-y') );
            $i++;
        }
        
        $j=0;
        if(! empty( $date_array ) ){
            foreach($date_array as $date){
                $total_present = Status::where('date', $date)->count();
                //$total_absent = $data['total_employees'] - $total_present;
                $absent_count[$j] = $data['total_employees'] - $total_present;
                //$absent_count = [5,2,3,1,1,4,3];
                $j++;
            }
        }

        $absent_7days = array();

        $i = 0;
        while ($i < 7) {
            $absent_7days[$i]['text'] = [$date_array[$i]];
            $absent_7days[$i]['values'] = $absent_count[$i];
            $i++;
        }

        $data['absent_7days']= json_encode($absent_7days);
        
        $i=0;
        $date = date('F Y');//Current Month Year
       
        while (strtotime($date) < strtotime(date('Y-m') . '-' . date('t', strtotime($date)))) {
            $date = date("Y-m-d", strtotime("+1 day", strtotime($date)));//Adds 1 day onto current date
            $date1 = date("m-d", strtotime("-1 day", strtotime($date)));//Adds 1 day onto current date
            $total_present = Status::where('date', $date)->count();
            $total_absent = $data['total_employees'] - $total_present;
            $result[$i]['label'] = $date1;
            $result[$i]['value'] = $total_absent;
            $i++;
        }
        
        $data['absentee_month'] = json_encode($result);
        
        //return view('dashboard.dashboardv4');
        
        return view('dashboard.dashboardv1',['data'=>$data]);
    }
}
