<?php

namespace App\Http\Controllers;

use App\Models\Roles;
use App\Models\User;
use App\Models\Department;
use App\Models\Location;
use App\Models\Status;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use RealRashid\SweetAlert\Toaster;

class UserController extends Controller
{

    public function index()
    {

        $users = User::where('status',0)->get();
        return view('backend.users.index', compact('users'));
    }

    public function create()
    {
        $roles = Roles::all();
        $departments = Department::all();
        $locations = Location::all();
        return view('backend.users.create', compact('roles','departments','locations'));
    }

    public function store(Request $request)
    {

        $department = $location = $dob = $gender = $blood_group = $marital_status = $iqama = $passport_no = $psprt_expiry_date = $office_employee="";
        
        if($request->input('role_name')=="Employee")
        {
            $department = $request->department_name;
            $location = $request->location_name;
            $dob = $request->dob;
            $gender = $request->gender;
            $blood_group = $request->blood_group;
            $marital_status = $request->marital_status;
            $iqama = $request->iqama;
            $passport_no = $request->passport_no;
            $psprt_expiry_date = $request->psprt_expiry_date;
            
            if(isset($_POST['office_employee']))
            $status = 1;
            else
            $status = 0;
            
            $office_employee = $status;

        }


        if (User::where('email', $request->email)->first() == null) {
            $user =  new User;
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            $user->phone = $request->phone;
            $user->user_type = $request->role_name;
            $user->department = $request->department_name;
            $user->location = $request->location_name;
            $user->dob = $dob;
            $user->gender = $gender;
            $user->blood_group = $blood_group;
            $user->marital_status = $marital_status;
            $user->iqama = $iqama;
            $user->passport_no = $passport_no;
            $user->psprt_expiry_date = $psprt_expiry_date;
            $user->office_employee = $office_employee;
            $user->save();
            $user->assignRole($request->role_name);
            toast('New User Added Successfully', 'success');
            return redirect()->route('users.index');
        } else {
            toast('Sorry Email is already used!', 'error');
            return back();
        }
    }

    public function show(User $user)
    {
        //
    }

    public function edit(Request $request, $id)
    {
        $user = User::findOrFail($id);
        $roles = Roles::all();
        $departments = Department::all();
        $locations = Location::all();
        return view('backend.users.edit', compact('user', 'roles', 'departments','locations'));
    }
    
    
    public function update_status()
    {
        $id = $_GET['id'];
        $user = User::findOrFail($id);
        $user->status = 1;

        if ($user->save()) {
            toast('User Info Updated Successfully', 'success');
            return redirect()->route('users.index');
        } else {
            toast('Something went wrong', 'error');
            return redirect()->route('users.index');
        }
    }


    public function update(Request $request, $id)
    {
        $department = $location = $dob = $gender = $blood_group = $marital_status = $iqama = $passport_no = $psprt_expiry_date = $office_employee="";

        if($request->input('role_name')=="Employee")
        {
            $department = $request->department_name;
            $location = $request->location_name;
            $dob = $request->dob;
            $gender = $request->gender;
            $blood_group = $request->blood_group;
            $marital_status = $request->marital_status;
            $iqama = $request->iqama;
            $passport_no = $request->passport_no;
            $psprt_expiry_date = $request->psprt_expiry_date;
            
            if(isset($_POST['office_employee']))
            $status = 1;
            else
            $status = 0;
            
            $office_employee = $status;
            

        }
        
        $user = User::findOrFail($id);
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->phone;
        $user->syncRoles($request->role_name);
        $user->user_type = $request->role_name;
        $user->department = $request->department_name;
        $user->location = $request->location_name;
        $user->dob = $dob;
        $user->gender = $gender;
        $user->blood_group = $blood_group;
        $user->marital_status = $marital_status;
        $user->iqama = $iqama;
        $user->passport_no = $passport_no;
        $user->psprt_expiry_date = $psprt_expiry_date;
        $user->office_employee = $office_employee;
        
        if($request->password)
        $user->password = Hash::make($request->password);

        if ($user->save()) {
            toast('User Info Updated Successfully', 'success');
            return redirect()->route('users.index');
        } else {
            toast('Something went wrong', 'error');
            return redirect()->route('users.index');
        }
    }

    public function destroy($id)
    {

        $user = User::find($id);
        $user->delete();
    }
    
    public function present_employees()
    {
        $total_present_emp = Status::where('date', date('Y-m-d'))->get();
        $present_id = array();
        $i=0;
        foreach($total_present_emp as $row)
        {
            $present_id[$i] = $row->user_id;
            $i++;
        }
        
        $users = User::where('status',0)->with('departments')->whereIn('id',$present_id)->take(5)->get();
       
        return view('backend.users.present_employees', compact('users'));
    }
    
    public function absent_employees()
    {
        $total_present_emp = Status::where('date', date('Y-m-d'))->get();
        $present_id = array();
        $i=0;
        foreach($total_present_emp as $row)
        {
            $present_id[$i] = $row->user_id;
            $i++;
        }
        
        $data['present_employees'] = User::whereIn('id',$present_id)->get();
        
        $total_emp = User::where('user_type','Employee')->get();
        $total_emp_id = array();
        $i=0;
        foreach($total_emp as $row)
        {
            $total_emp_id[$i] = $row->id;
            $i++;
        }
        
        $users = User::where('status',0)->whereIn('id',$total_emp_id)->whereNotIn('id',$present_id)->groupBy('id')->get();
       
        return view('backend.users.present_employees', compact('users'));
    }
    
    public function employees()
    {
        
        $users = User::where('status',0)->with('departments')->where('user_type','Employee')->get();
       
        return view('backend.users.present_employees', compact('users'));
    }
}
