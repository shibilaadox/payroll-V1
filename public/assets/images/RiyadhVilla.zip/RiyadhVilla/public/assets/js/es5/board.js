'use strict';

dragula([document.getElementById('left-defaults'), document.getElementById('right-defaults'), document.getElementById('left-defaults-l'), document.getElementById('right-defaults-l')]);