<div class="card-body">
    <h4 class="card-title mb-3">Add Variation</h4>

    <div class="table-responsive" style="overflow-x: unset; !important;">
        <table class="table table-borderless ">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Variation</th>
                    <th scope="col">Variation Values</th>
                    <th scope="col">Variation Cost</th>
                    <th scope="col">Variation Price</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">
                        <select class="selectpicker form-group show-tick" data-style="btn-primary-outline" id="attribute"
                            data-live-search="true" data-width="" name="choice_options[]">
                            <option>Please select</option>
                            @foreach ($attributes as $attr)
                                <option value="{{ $attr->id }}">{{ $attr->name }}
                                </option>
                            @endforeach
                        </select>
                    </th>
                    <td>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>Small</td>
                    <td>900.23</td>
                    <td>1000.10</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
