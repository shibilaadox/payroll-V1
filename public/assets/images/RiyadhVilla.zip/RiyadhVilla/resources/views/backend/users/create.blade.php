@extends('layouts.master')
<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<style type="text/css">
	
	.toggle
	{
		width: 83px !important; 
	}
	
</style>
@section('main-content')
    <div class="breadcrumb">
        <h1>Create Staffs</h1>
    </div>
    <div class="separator-breadcrumb border-top"></div>
    <section class="basic-action-bar">
        <div class="row mb-8">
            <div class="col-lg-2"></div>
            <div class="col-lg-8 mb-3">
                <!--begin::form 2-->
                <form action="{{ route('users.store') }}" method="POST" class="needs-validation was-validated">
                    @csrf
                    <!-- start card  Horizontal Form Layout-->
                    <div class="card ul-card__margin-20">
                        <div class="card-header bg-transparent">
                            <h3 class="card-title">User Information</h3>
                        </div>

                        <div class="card-body">
                            <div class="form-group row">
                                <label for="staticName" class="action-bar-horizontal-label col-lg-4 col-form-label ">Full
                                    Name:</label>
                                <div class="col-lg-6 mb-4">
                                    <input type="text" class="form-control" id="staticName" placeholder="Enter full name"
                                        name="name" required>

                                </div>
                                <label for="staticEmail" class="action-bar-horizontal-label col-lg-4 col-form-label ">Email
                                </label>
                                <div class="col-lg-6  mb-4">
                                    <input type="text" class="form-control" name="email" id="staticEmail"
                                        placeholder="Enter Email" required>

                                </div>
                                <label for="staticPhone" class="action-bar-horizontal-label col-lg-4 col-form-label ">Phone
                                </label>
                                <div class="col-lg-6  mb-4">
                                    <input type="text" class="form-control" name="phone" id="staticPhone"
                                        placeholder="Enter Phone number" required>

                                </div>
                                <label for="staticPassword"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label ">Password </label>
                                <div class="col-lg-6  mb-4">
                                    <input type="text" class="form-control" id="staticPassword"
                                        placeholder="Enter Password" required name="password">

                                </div>

                                <label for="staticRole"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label">Role:</label>
                                <div class="col-lg-6  mb-4">
                                    <select class="form-control" name="role_name" id="role_name" required>
                                        @foreach ($roles as $role)
                                            <option value="{{ $role->name }}">{{ $role->name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                               
                                <label for="staticDepartment" style="display: none;" 
                                    class="action-bar-horizontal-label col-lg-4 col-form-label" id="label_department">Department:</label>
                                <div class="col-lg-6  mb-4" style="display: none;" id="div_department">
                                    <select class="form-control" name="department_name" id="department_name">
                                        <option value="">Select a department</option>
                                        @foreach ($departments as $department)
                                            <option value="{{ $department->id }}">{{ $department->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                               

                               
                                <label for="staticLocation" style="display: none;" id="label_location"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label">Location:</label>
                                <div class="col-lg-6  mb-4" style="display: none;" id="div_location">

                                    <select class="form-control" name="location_name" id="location_name">
                                        <option value="">Select a location</option>
                                        @foreach ($locations as $location)
                                            <option value="{{ $location->id }}">{{ $location->location_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                
                                <label for="staticDOB" style="display: none;" id="label_dob"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label">DOB:</label>
                                <div class="col-lg-6  mb-4" style="display: none;" id="div_dob">

                                    <input type="text" class="form-control" id="dob"
                                        placeholder="Enter Password" name="dob">
                                </div>
                                
                                <label for="staticGender" style="display: none;" id="label_gender"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label">Gender:</label>
                                <div class="col-lg-6  mb-4" style="display: none;" id="div_gender">

                                    <select class="form-control" name="gender" id="gender">
                                        <option value="">Select a gender</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Other">Other</option>
                                       
                                    </select>
                                </div>
                                
                                <label for="staticBlood" style="display: none;" id="label_blood"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label">Blood Group:</label>
                                <div class="col-lg-6  mb-4" style="display: none;" id="div_blood">
                                <select class="form-control" name="blood_group" id="blood_group">
                                    <option value="">Select a blood group</option>
                                    <option>A+</option>
                                    <option>A-</option>
                                    <option>B+</option>
                                    <option>B-</option>
                                    <option>AB+</option>
                                    <option>AB-</option>
                                    <option>O+</option>
                                    <option>O-</option>
                                    <option>Unknown</option>
                                </select>
                                    
                                </div>
                                
                                <label for="staticStatus" style="display: none;" id="label_mar_status"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label">Marital Status:</label>
                                <div class="col-lg-6  mb-4" style="display: none;" id="div_mar_status">

                                    <select name="marital_status" id="marital_status" class="form-control">
                                    <option value="">Select a marital status</option>       
                                    <option value="Single">Single</option>
                                    <option value="Married">Married</option>
                                    <option value="Widowed">Widowed</option>
                                    <option value="Separated">Separated</option>
                                    <option value="Divorced">Divorced</option>
                                    
                                    </select>
                                </div>
                                
                                <label for="staticIqama" style="display: none;" id="label_iqama"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label">Iqama No:</label>
                                <div class="col-lg-6  mb-4" style="display: none;" id="div_iqama">

                                    <input type="text" class="form-control" id="iqama"
                                        placeholder="Enter Iqama No" name="iqama">
                                </div>
                                
                                <label for="staticPassport" style="display: none;" id="label_passport_no"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label">Passport No:</label>
                                <div class="col-lg-6  mb-4" style="display: none;" id="div_passport_no">

                                    <input type="number" class="form-control" id="passport_no"
                                        placeholder="Enter Passport No" name="passport_no">
                                </div>
                                
                                <label for="staticPsprtDate" style="display: none;" id="label_psprt_expiry_date"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label">Passport Expiry Date:</label>
                                <div class="col-lg-6  mb-4" style="display: none;" id="div_psprt_expiry_date">

                                    <input type="text" class="form-control" id="psprt_expiry_date"
                                        placeholder="Enter Password" name="psprt_expiry_date">
                                </div>
                                
                                 <label for="staticOffice" style="display: none;" id="label_office_employee"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label">Office Employee:</label>
                                <div class="col-lg-6  mb-4" style="display: none;" id="div_office_employee">
                                    <input type="checkbox" checked data-toggle="toggle" data-on="Office" data-off="Moving" data-onstyle="success" data-offstyle="danger" id="office_employee"  name="office_employee" value="1">
                                </div>
                                
                                
                                
                               
                            </div>



                        </div>
                        <div class="card-footer">
                            <div class="mc-footer">
                                <div class="row text-right">
                                    <div class="col-lg-4"></div>
                                    <div class="col-lg-6 text-left">
                                        <button type="submit"  class="btn btn-primary m-1">Save</button>
                                        <button type="button" class="btn btn-outline-secondary m-1">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end card  Horizontal Form Layout-->
                </form>
                <!-- end::form 2-->
            </div>
            <div class="col-lg-3"></div>
        </div>
    </section>

@endsection
@section('page-js')

<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
<script type="text/javascript">
    
    $("#role_name").change(function(){

        if($("#role_name").val()=="Employee")
        {
            $("#label_department").show();
            $("#div_department").show();
            $("#label_location").show();
            $("#div_location").show();
            $("#label_dob").show();
            $("#div_dob").show();
            $("#label_gender").show();
            $("#div_gender").show();
            $("#label_blood").show();
            $("#div_blood").show();
            $("#label_mar_status").show();
            $("#div_mar_status").show();
            $("#label_iqama").show();
            $("#div_iqama").show();
            $("#label_passport_no").show();
            $("#div_passport_no").show();
            $("#label_psprt_expiry_date").show();
            $("#div_psprt_expiry_date").show();
            $("#label_office_employee").show();
            $("#div_office_employee").show();
        }

        else
        {
            $("#label_department").hide();
            $("#div_department").hide();
            $("#label_location").hide();
            $("#div_location").hide();
            $("#label_dob").hide();
            $("#div_dob").hide();
            $("#label_gender").hide();
            $("#div_gender").hide();
            $("#label_blood").hide();
            $("#div_blood").hide();
            $("#label_mar_status").hide();
            $("#div_mar_status").hide();
            $("#label_iqama").hide();
            $("#div_iqama").hide();
            $("#label_passport_no").hide();
            $("#div_passport_no").hide();
            $("#label_psprt_expiry_date").hide();
            $("#div_psprt_expiry_date").hide();
            $("#label_office_employee").hide();
            $("#div_office_employee").hide();
        }

    });
    
    
      $('input[name="dob"]').daterangepicker({
        singleDatePicker: true,
         locale: {
          format: 'YYYY/MM/DD',
        },
        showDropdowns: true,
        minYear: 1901,
        maxYear: parseInt(moment().format('YYYY'),10)
      }); 
   
    
    $('input[name="psprt_expiry_date"]').daterangepicker({
        singleDatePicker: true,
         locale: {
          format: 'YYYY/MM/DD',
        },
        showDropdowns: true,
        minYear: 1901,
        //maxYear: parseInt(moment().format('YYYY'),10)
      }); 
   


</script>

@endsection

