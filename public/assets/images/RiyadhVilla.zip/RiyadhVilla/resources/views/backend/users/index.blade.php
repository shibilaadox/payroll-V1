@extends('layouts.master')
@section('page-css')

    <link rel="stylesheet" href="{{ asset('assets/styles/vendor/datatables.min.css') }}">
@endsection

@section('main-content')
    <div class="breadcrumb">
        <h1>All Users</h1>

    </div>
    <div class="separator-breadcrumb border-top"></div>
    <section class="basic-action-bar">
        <!-- end of row -->

        <div class="row mb-4">
            <div class="col-md-12 mb-3">
                <div class="card text-left">
                    <div class="card-body">
                        <h4 class="card-title mt-1" style="text-align: end;"><button type="button"
                                class="btn btn-primary ripple m-1"><a style="color: white"
                                    href="{{ route('users.create') }}">
                                    New User</a></button></h4>

                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Phone</th>
                                        <th scope="col">Role</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {{-- <tr>
                                        <th scope="row">1</th>
                                        <td>Admin</td>
                                    </tr> --}}
                                    @php
                                        $i = 1;
                                    @endphp
                                    @foreach ($users as $row)
                                        <tr>
                                            <th scope="row">{{ $i++ }}</th>
                                            <td>{{ $row->name }}</td>
                                            <td>{{ $row->email }}</td>
                                            <td>{{ $row->phone }}</td>
                                            <td><span
                                                    class="badge badge-success">{{ $row->user_type }}</span>
                                            </td>
                                            <td>
                                                <a class="text-success mr-2" href="{{ route('users.edit', $row->id) }}">
                                                    <i class="nav-icon i-Pen-2 font-weight-bold fs-16"></i>
                                                </a>
                                                <a class="text-danger mr-2" onclick="delete_user('{{$row->id}}')" title="Disbale employee">
                                                    <i class="nav-icon i-Close-Window font-weight-bold fs-16"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>


                    </div>
                </div>
            </div>
            <!-- end of col-->

        </div>
        <!-- end of row -->
    </section>

@endsection

@section('page-js')

<script>
   
        function delete_user(id) {
           
            event.preventDefault();
            let _token = $('meta[name="csrf-token"]').attr('content');
            
            $.ajax({
                url: "<?php echo url('update_status'); ?>",
                type: "GET",
                data: {id:id},
                cache: false,
                
                success: function(response) {
                   
                    // console.log(response.code);
                    if (response) {

                        swal({
            type: 'success',
            title: 'Success!',
            text: 'User status is changed successfully',
            buttonsStyling: false,
            confirmButtonClass: 'btn btn-lg btn-success'
        }).then(function() {
            location.reload();
        });


                    }
                },
                error: function(response) {
                    
                }

            });
            
        }
</script>


@endsection
