<div class="side-content-wrap">
    <div class="sidebar-left open rtl-ps-none" data-perfect-scrollbar data-suppress-scroll-x="true" style="
    background: orange;">
        <ul class="navigation-left">
            <li class="nav-item {{ request()->is('home/*') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{route('home')}}">
                    <i class="nav-icon i-Bar-Chart"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item {{ request()->is('roles/*') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{route('roles.index')}}">
                    <i class="nav-icon i-Library"></i>
                    <span class="nav-text">Roles</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item {{ request()->is('users/*') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{route('users.index')}}">
                    <i class="nav-icon i-Library"></i>
                    <span class="nav-text">Users</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item {{ request()->is('departments/*') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{route('departments.index')}}">
                    <i class="nav-icon i-Library"></i>
                    <span class="nav-text">{{__('Departments')}}</span>
                </a>
                <div class="triangle"></div>
            </li>

            <li class="nav-item {{ request()->is('locations/*') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{route('locations.index')}}">
                    <i class="nav-icon i-Library"></i>
                    <span class="nav-text">{{__('Locations')}}</span>
                </a>
                <div class="triangle"></div>
            </li>
            
            <li class="nav-item {{ request()->is('track/*') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{route('track')}}">
                    <i class="nav-icon i-Library"></i>
                    <span class="nav-text">{{__('Track Employees')}}</span>
                </a>
                <div class="triangle"></div>
            </li>
            
            <li class="nav-item {{ request()->is('news/*') ? 'active' : '' }}">
                <a class="nav-item-hold" href="{{route('news.index')}}">
                    <i class="nav-icon i-Library"></i>
                    <span class="nav-text">{{__('News')}}</span>
                </a>
                <div class="triangle"></div>
            </li>
            
         </ul>
    </div>

    <div class="sidebar-left-secondary rtl-ps-none emdad_side_bar" data-perfect-scrollbar data-suppress-scroll-x="true">
        <!-- Submenu Dashboards -->
       
        
        
         
    </div>
    <div class="sidebar-overlay"></div>
</div>
<!--=============== Left side End ================-->