
<?php $__env->startSection('page-css'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/vendor/datatables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="breadcrumb">
        <h1>All Staffs</h1>

    </div>
    <div class="separator-breadcrumb border-top"></div>
    <section class="basic-action-bar">
        <!-- end of row -->

        <div class="row mb-4">
            <div class="col-md-12 mb-3">
                <div class="card text-left">
                    <div class="card-body">
                        <h4 class="card-title mt-1" style="text-align: end;"><button type="button"
                                class="btn btn-primary ripple m-1"><a style="color: white"
                                    href="<?php echo e(route('staff.create')); ?>">
                                    New Staff</a></button></h4>

                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Phone</th>
                                        <th scope="col">Role</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($i++); ?></th>
                                            <td><?php echo e($staff->name); ?></td>
                                            <td><?php echo e($staff->email); ?></td>
                                            <td><?php echo e($staff->phone); ?></td>
                                            <td><span
                                                    class="badge badge-success"><?php echo e($staff->getRoleNames()->first()); ?></span>
                                            </td>
                                            <td>
                                                <a class="text-success mr-2" href="<?php echo e(route('staff.edit', $staff->id)); ?>">
                                                    <i class="nav-icon i-Pen-2 font-weight-bold fs-16"></i>
                                                </a>
                                                <a class="text-danger mr-2" onclick="remove(<?php echo e($staff->id); ?>,'staff')">
                                                    <i class="nav-icon i-Close-Window font-weight-bold fs-16"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>


                    </div>
                </div>
            </div>
            <!-- end of col-->

        </div>
        <!-- end of row -->
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Finance\resources\views/backend/staff/staffs/index.blade.php ENDPATH**/ ?>