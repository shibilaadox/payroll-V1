<!-- Footer Start -->
<div class="flex-grow-1"></div>
<div class="app-footer">
    
</div>
<!-- fotter end --><?php /**PATH C:\xampp\htdocs\Emdad\resources\views/layouts/common/footer.blade.php ENDPATH**/ ?>