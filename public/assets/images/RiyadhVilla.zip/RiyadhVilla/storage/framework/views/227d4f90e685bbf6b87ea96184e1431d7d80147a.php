
<?php $__env->startSection('main-content'); ?>
           <div class="breadcrumb">
                
                <ul>
                    <li><a href="" style="color:green;font-size:18px;">Admin Dashboard</a></li>
                    
                </ul>
            </div>

            <div class="separator-breadcrumb border-top"></div>

            <div class="row">
                <!-- ICON BG -->
                
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <a href="<?php echo e(route('employees')); ?>">
                    <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4 bg-warning">
                        <div class="card-body text-center">
                        <i class="i-Add-User"></i>    
                            <div class="content">
                                <p class="text-white text-24 line-height-1 mb-2"><?php echo e($data['total_employees']); ?></p>
                                <p class="text-white mt-2 mb-0">Employees</p>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-6">
                    <a href="<?php echo e(route('absent_employees')); ?>">
                    <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4 bg-danger">
                        <div class="card-body text-center">
                        <i class="i-Add-User"></i>
                            <div class="content">
                                <p class="text-white text-24 line-height-1 mb-2"><?php echo e($data['total_absent']); ?></p>
                                <p class="text-white mt-2 mb-0">Absent</p>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>
                
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <a href="<?php echo e(route('present_employees')); ?>">
                    <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4 bg-success">
                        <div class="card-body text-center">
                        <i class="i-Add-User"></i>
                            <div class="content">
                                <p class="text-white text-24 line-height-1 mb-2"><?php echo e($data['total_present']); ?></p>
                                <p class="text-white mt-2 mb-0">Present</p>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>
                
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <a href="<?php echo e(route('departments.index')); ?>">
                    <div class="card card-icon-bg card-icon-bg-primary o-hidden mb-4 bg-warning">
                        <div class="card-body text-center">
                        <i class="i-Library"></i>    
                            <div class="content">
                                <p class="text-white text-24 line-height-1 mb-2"><?php echo e($data['total_departments']); ?></p>
                                <p class="text-white mt-2 mb-0">Departments</p>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>
                

            </div>

            <div class="row" style="margin-top:3%">
                <div class="col-lg-7 col-md-12">
                    <div class="card mb-4" >
                        <div class="card-header d-flex align-items-center border-0 bg-info">
                            <h3 class="w-50 float-left card-title m-0" style="color:white;font-size:15px;"><?php echo e(__('Monthly Attendance Summary')); ?></h3>
                                    
                        </div>
                        <div class="card-body">
                            
                            <div class="m-widget3__item">
                                                
                                                    
                                            <canvas id="myChart1" width="200" height="100"></canvas>
                                                
                                                
                                            
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-5 col-md-12">


                    <div class="row">
                        <div class="col-md-12">
                            <div class="card o-hidden mb-4">
                                <div class="card-header d-flex align-items-center border-0 bg-info">
                                    <h3 class="w-50 float-left card-title m-0" style="color:white;font-size:15px;">Today's Present Employees</h3>
                                    <h4 class="card-title mt-1" style="text-align: end;margin-left:34%;"><button type="button"
                                    class="btn btn-success btn-sm"><a style="color: white"
                                    href="<?php echo e(route('present_employees')); ?>">
                                    View All</a></button></h4>
                                    
                                </div>

                                <div class="">
                                    <div class="table-responsive">
                                        <table id="user_table" class="table  text-center">
                                            <thead>
                                                <tr style="font-size:14px;">
                                                    <th scope="col">#</th>
                                                    <th scope="col">Name</th>
                                                    <th scope="col">Avatar</th>
                                                    <th scope="col">Email</th>
                                                    <th scope="col">Status</th>
                                                   
                                                </tr>
                                            </thead>
                                            <tbody>
                                               
                                                    <?php $i=1;foreach($data['present_employees'] as $row){?>
                                                    <tr style="font-size:12px;">
                                                    <th scope="row"><?php echo e($i); ?></th>
                                                    <td><?php echo e($row->name); ?></td>
                                                    <td>

                                                        <img class="rounded-circle m-0 avatar-sm-table " src="/assets/images/faces/1.jpg" alt="">

                                                    </td>

                                                    <td><?php echo e($row->email); ?></td>
                                                    <td><span class="badge badge-success">Active</span></td>
                                                    
                                                </tr>
                                                <?php $i++;} ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>

                </div>
            </div>

            <div class="row" style="margin-top:3%">
                
                <div class="col-lg-6 col-sm-12">
                    <div class="card mb-4" style="height:350px;">
                        <div class="card-header d-flex align-items-center border-0 bg-info">
                            <h3 class="w-70 float-left card-title m-0" style="color:white;font-size:15px;"><?php echo e(__('Absentees Last 7 Days')); ?></h3>
                        </div>
                        <div class="card-body">
                           
                            <div class="m-widget3__item">
                                                
                                                    
                                <canvas id="myChart2" width="450" height="250"></canvas>
                                                
                                                
                                            
                            </div>
                        </div>
                    </div>
                </div>
                
               
                
                
                <div class="col-md-6">
                            <div class="card o-hidden mb-4">
                                <div class="card-header d-flex align-items-center border-0 bg-info">
                                    <h3 class="w-50 float-left card-title m-0" style="color:white;font-size:15px;">Absentees Today</h3>
                                    
                                </div>

                                <div class="">
                                    <div class="table-responsive">
                                        <table id="user_table" class="table  text-center">
                                            <thead>
                                                <tr style="font-size:14px;">
                                                    <th scope="col">#</th>
                                                    <th scope="col">Name</th>
                                                    <th scope="col">Email</th>
                                                    <th scope="col">Phone</th>
                                                    <th scope="col">Role</th>
                                                   
                                                </tr>
                                            </thead>
                                            <tbody>
                                                
                                                <?php $i=1;foreach($data['total_absent_emp'] as $row){?>
                                                <tr style="font-size:12px;">
                                                    <th scope="row"><?php echo e($i); ?></th>
                                                    <td><?php echo e($row->name); ?></td>
                                                    <td><?php echo e($row->email); ?></td>
                                                    <td><?php echo e($row->phone); ?></td>
                                                    <td><span
                                                    class="badge badge-success"><?php echo e($row->user_type); ?></span>
                                                    </td>
                                                    
                                                </tr>
                                                <?php $i++;} ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>


                        </div>
                
                

            </div>
                    
                <div class="row" style="margin-top:3%">
                
                <div class="col-lg-12 col-sm-12">
                    <div class="card mb-4">
                        <div class="card-header d-flex align-items-center border-0 bg-info">
                            <h3 class="w-70 float-left card-title m-0" style="color:white;font-size:15px;"><?php echo e(__('Absentees This Month')); ?></h3>
                        </div>
                        <div class="card-body">
                           
                            <div class="m-widget3__item">
                                                
                                                    
                                <canvas id="myChart5" width="450"></canvas>
                                                
                                                
                                            
                            </div>
                        </div>
                    </div>
                </div>
                
                </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
    <script src="https://code.jquery.com/jquery-1.11.0.min.js"></script
    <script src="<?php echo e(asset('assets/js/vendor/echarts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/es5/echart.options.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/es5/dashboard.v1.script.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.5.1/chart.min.js"></script>
    
    <script type="text/javascript">
    var chartDiv1 = $("#myChart1");
    var monthly_attendance = <?php echo $data['monthly_attendance']?>;
    
    labels1 = [];
    data1= [];

    for (var i =0; i< monthly_attendance.length ;i++) {
        labels1[i] = monthly_attendance[i].text;
        data1[i] = monthly_attendance[i].values;
    }

    var MonthlyAttendance = {
    label: "Count",
    data: data1,
    backgroundColor: ["#0c0c7a"],
    barThickness: 35,
    };
 
    var barChart = new Chart(chartDiv1, {
    type: 'bar',
    data: {
    labels: labels1,
    datasets: [MonthlyAttendance]
    }
    });
    
    var chartDiv2 = $("#myChart2");
    var absent_7days = <?php echo $data['absent_7days']?>;
    labels2 = [];
    data2= [];


    for (var i =0; i< absent_7days.length ;i++) {
        labels2[i] = absent_7days[i].text;
        data2[i] = absent_7days[i].values;
    }
   
    var myChart2 = new Chart(chartDiv2, {
    type: 'doughnut',
    data: {
        labels: labels2,
        datasets: [
        {
            data: data2,
            backgroundColor: ["#c76161","#91cf91","#7157d8","#e2b564","#e37fe3","#e2e263","#84ebe8"]
        }]
    },
    options: {
        title: {
            display: true,
            text: 'Doughnut Chart'
        },
        /*plugins: {
        legend: {
        display: false
        }
    },*/
        elements: {
        arc: {
            borderWidth: 0.5
        }
    },
        responsive: true,
        maintainAspectRatio: false,
    }
    });
    
    
    
    var absentee_month = <?php echo $data['absentee_month']?>;
    labels5 = [];
    data5= [];


    for (var i =0; i< absentee_month.length ;i++) {
        labels5[i] = absentee_month[i].label;
        data5[i] = absentee_month[i].value;
    }


    var absentee_month = {
    labels: labels5,
    datasets: [{
        label: "Absentees",
        data: data5,
        borderColor: ["#5f985f"],
        backgroundColor: 'transparent',
    }]
    };
 
    var chartOptions = {
    legend: {
    display: true,
    position: 'top',
    labels: {
     
      fontColor: 'black'
    }
    }
    };


    var chartDiv5 = $("#myChart5");

    var lineChart = new Chart(chartDiv5, {
        type: 'line',
        data: absentee_month,
        options: chartOptions
    });
    
    </script>
    <?php $__env->stopSection(); ?>

     
   

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/adoxamuf/public_html/apps/bloomax/resources/views/dashboard/dashboardv1.blade.php ENDPATH**/ ?>