<div class="side-content-wrap">
    <div class="sidebar-left open rtl-ps-none" data-perfect-scrollbar data-suppress-scroll-x="true">
        <ul class="navigation-left">
            <li class="nav-item <?php echo e(request()->is('dashboard/*') ? 'active' : ''); ?>">
                <a class="nav-item-hold" href="#">
                    <i class="nav-icon i-Bar-Chart"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item <?php echo e(request()->is('staffs/*') ? 'active' : ''); ?>" data-item="staffs">
                <a class="nav-item-hold" href="#">
                    <i class="nav-icon i-Library"></i>
                    <span class="nav-text">User Managment</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item <?php echo e(request()->is('staffs/*') ? 'active' : ''); ?>" data-item="products">
                <a class="nav-item-hold" href="#">
                    <i class="nav-icon i-Library"></i>
                    <span class="nav-text">Products</span>
                </a>
                <div class="triangle"></div>
            </li>

            <li class="nav-item <?php echo e(request()->is('businesscategory/*') ? 'active' : ''); ?>" data-item="sellers">
                <a class="nav-item-hold" href="#">
                    <i class="nav-icon i-Library"></i>
                    <span class="nav-text">Sellers</span>
                </a>
                <div class="triangle"></div>
            </li>
            
         </ul>
    </div>

    <div class="sidebar-left-secondary rtl-ps-none emdad_side_bar" data-perfect-scrollbar data-suppress-scroll-x="true">
        <!-- Submenu Dashboards -->
       
        <ul class="childNav" data-parent="staffs">
            <li class="nav-item">
                <a class="<?php echo e(Route::currentRouteName()=='alerts' ? 'open' : ''); ?>" href="<?php echo e(route('staff.index')); ?>">
                    <i class="nav-icon i-Bell1"></i>
                    <span class="item-name">All Staffs</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="<?php echo e(Route::currentRouteName()=='accordion' ? 'open' : ''); ?>" href="<?php echo e(route('roles.index')); ?>">
                    <i class="nav-icon i-Split-Horizontal-2-Window"></i>
                    <span class="item-name">Staff Permissions</span>
                </a>
            </li>
        </ul>
        <ul class="childNav" data-parent="products">
            <li class="nav-item">
                <a class="<?php echo e(Route::currentRouteName()=='alerts' ? 'open' : ''); ?>" href="<?php echo e(route('product.create')); ?>">
                    <i class="nav-icon i-Bell1"></i>
                    <span class="item-name">Add New Product</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="<?php echo e(Route::currentRouteName()=='accordion' ? 'open' : ''); ?>" href="<?php echo e(route('product.index')); ?>">
                    <i class="nav-icon i-Split-Horizontal-2-Window"></i>
                    <span class="item-name">List Product</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="<?php echo e(Route::currentRouteName()=='accordion' ? 'open' : ''); ?>" href="<?php echo e(route('brand.index')); ?>">
                    <i class="nav-icon i-Split-Horizontal-2-Window"></i>
                    <span class="item-name">Brands</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="<?php echo e(Route::currentRouteName()=='accordion' ? 'open' : ''); ?>" href="<?php echo e(route('category.index')); ?>">
                    <i class="nav-icon i-Split-Horizontal-2-Window"></i>
                    <span class="item-name">Categories</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="<?php echo e(Route::currentRouteName()=='accordion' ? 'open' : ''); ?>" href="<?php echo e(route('subcategory.index')); ?>">
                    <i class="nav-icon i-Split-Horizontal-2-Window"></i>
                    <span class="item-name">Sub Categories</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="<?php echo e(Route::currentRouteName()=='accordion' ? 'open' : ''); ?>" href="<?php echo e(route('attribute.index')); ?>">
                    <i class="nav-icon i-Split-Horizontal-2-Window"></i>
                    <span class="item-name">Attributes</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="<?php echo e(Route::currentRouteName()=='accordion' ? 'open' : ''); ?>" href="<?php echo e(route('unit.index')); ?>">
                    <i class="nav-icon i-Split-Horizontal-2-Window"></i>
                    <span class="item-name">Units</span>
                </a>
            </li>
        </ul>

         <ul class="childNav" data-parent="sellers">
            <li class="nav-item">
                <a class="<?php echo e(Route::currentRouteName()=='alerts' ? 'open' : ''); ?>" href="<?php echo e(route('businesscategory.index')); ?>">
                    <i class="nav-icon i-Bell1"></i>
                    <span class="item-name">Business Category</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="<?php echo e(Route::currentRouteName()=='alerts' ? 'open' : ''); ?>" href="<?php echo e(route('seller.index')); ?>">
                    <i class="nav-icon i-Bell1"></i>
                    <span class="item-name">All Sellers</span>
                </a>
            </li>
           
        </ul>
         
    </div>
    <div class="sidebar-overlay"></div>
</div>
<!--=============== Left side End ================--><?php /**PATH C:\xampp\htdocs\Emdad\resources\views/layouts/large-vertical-sidebar/sidebar.blade.php ENDPATH**/ ?>