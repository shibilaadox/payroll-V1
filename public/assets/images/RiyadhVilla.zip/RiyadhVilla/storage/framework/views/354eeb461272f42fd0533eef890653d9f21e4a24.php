
<?php $__env->startSection('page-css'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/vendor/datatables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="breadcrumb">
        <h1>All Users</h1>

    </div>
    <div class="separator-breadcrumb border-top"></div>
    <section class="basic-action-bar">
        <!-- end of row -->

        <div class="row mb-4">
            <div class="col-md-12 mb-3">
                <div class="card text-left">
                    <div class="card-body">
                        <h4 class="card-title mt-1" style="text-align: end;"><button type="button"
                                class="btn btn-primary ripple m-1"><a style="color: white"
                                    href="<?php echo e(route('users.create')); ?>">
                                    New User</a></button></h4>

                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Phone</th>
                                        <th scope="col">Role</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($i++); ?></th>
                                            <td><?php echo e($row->name); ?></td>
                                            <td><?php echo e($row->email); ?></td>
                                            <td><?php echo e($row->phone); ?></td>
                                            <td><span
                                                    class="badge badge-success"><?php echo e($row->user_type); ?></span>
                                            </td>
                                            <td>
                                                <a class="text-success mr-2" href="<?php echo e(route('users.edit', $row->id)); ?>">
                                                    <i class="nav-icon i-Pen-2 font-weight-bold fs-16"></i>
                                                </a>
                                                <a class="text-danger mr-2" onclick="delete_user('<?php echo e($row->id); ?>')" title="Disbale employee">
                                                    <i class="nav-icon i-Close-Window font-weight-bold fs-16"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>


                    </div>
                </div>
            </div>
            <!-- end of col-->

        </div>
        <!-- end of row -->
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

<script>
   
        function delete_user(id) {
           
            event.preventDefault();
            let _token = $('meta[name="csrf-token"]').attr('content');
            
            $.ajax({
                url: "<?php echo url('update_status'); ?>",
                type: "GET",
                data: {id:id},
                cache: false,
                
                success: function(response) {
                   
                    // console.log(response.code);
                    if (response) {

                        swal({
            type: 'success',
            title: 'Success!',
            text: 'User status is changed successfully',
            buttonsStyling: false,
            confirmButtonClass: 'btn btn-lg btn-success'
        }).then(function() {
            location.reload();
        });


                    }
                },
                error: function(response) {
                    
                }

            });
            
        }
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/adoxamuf/public_html/apps/RiyadhVilla/resources/views/backend/users/index.blade.php ENDPATH**/ ?>