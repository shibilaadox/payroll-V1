<div class="side-content-wrap">
    <div class="sidebar-left open rtl-ps-none" data-perfect-scrollbar data-suppress-scroll-x="true" style="
    background: orange;">
        <ul class="navigation-left">
            <li class="nav-item <?php echo e(request()->is('home/*') ? 'active' : ''); ?>">
                <a class="nav-item-hold" href="<?php echo e(route('home')); ?>">
                    <i class="nav-icon i-Bar-Chart"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item <?php echo e(request()->is('roles/*') ? 'active' : ''); ?>">
                <a class="nav-item-hold" href="<?php echo e(route('roles.index')); ?>">
                    <i class="nav-icon i-Library"></i>
                    <span class="nav-text">Roles</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item <?php echo e(request()->is('users/*') ? 'active' : ''); ?>">
                <a class="nav-item-hold" href="<?php echo e(route('users.index')); ?>">
                    <i class="nav-icon i-Library"></i>
                    <span class="nav-text">Users</span>
                </a>
                <div class="triangle"></div>
            </li>
            <li class="nav-item <?php echo e(request()->is('departments/*') ? 'active' : ''); ?>">
                <a class="nav-item-hold" href="<?php echo e(route('departments.index')); ?>">
                    <i class="nav-icon i-Library"></i>
                    <span class="nav-text"><?php echo e(__('Departments')); ?></span>
                </a>
                <div class="triangle"></div>
            </li>

            <li class="nav-item <?php echo e(request()->is('locations/*') ? 'active' : ''); ?>">
                <a class="nav-item-hold" href="<?php echo e(route('locations.index')); ?>">
                    <i class="nav-icon i-Library"></i>
                    <span class="nav-text"><?php echo e(__('Locations')); ?></span>
                </a>
                <div class="triangle"></div>
            </li>
            
            <li class="nav-item <?php echo e(request()->is('track/*') ? 'active' : ''); ?>">
                <a class="nav-item-hold" href="<?php echo e(route('track')); ?>">
                    <i class="nav-icon i-Library"></i>
                    <span class="nav-text"><?php echo e(__('Track Employees')); ?></span>
                </a>
                <div class="triangle"></div>
            </li>
            
            <li class="nav-item <?php echo e(request()->is('news/*') ? 'active' : ''); ?>">
                <a class="nav-item-hold" href="<?php echo e(route('news.index')); ?>">
                    <i class="nav-icon i-Library"></i>
                    <span class="nav-text"><?php echo e(__('News')); ?></span>
                </a>
                <div class="triangle"></div>
            </li>
            
         </ul>
    </div>

    <div class="sidebar-left-secondary rtl-ps-none emdad_side_bar" data-perfect-scrollbar data-suppress-scroll-x="true">
        <!-- Submenu Dashboards -->
       
        
        
         
    </div>
    <div class="sidebar-overlay"></div>
</div>
<!--=============== Left side End ================--><?php /**PATH /home2/adoxamuf/public_html/apps/bloomax/resources/views/layouts/large-vertical-sidebar/sidebar.blade.php ENDPATH**/ ?>