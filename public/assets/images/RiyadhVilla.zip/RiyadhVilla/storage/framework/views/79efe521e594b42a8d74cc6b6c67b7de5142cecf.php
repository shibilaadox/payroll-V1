
<?php $__env->startSection('page-css'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/vendor/datatables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="breadcrumb">
        <h1>All Roles</h1>

    </div>
    <div class="separator-breadcrumb border-top"></div>
    <section class="basic-action-bar">
        <!-- end of row -->

        <div class="row mb-4">


            <div class="col-md-12 mb-3">
                <div class="card text-left">

                    <div class="card-body">
                        <h4 class="card-title mb-3" style="text-align: end;"><button type="button"
                                class="btn btn-primary ripple m-1"><a style="color: white"
                                    href="<?php echo e(route('roles.create')); ?>">
                                    New Role</a></button></h4>

                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Name</th>

                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <th scope="row"><?php echo e($i++); ?></th>
                                            <td><?php echo e($role->name); ?></td>

                                            <td>
                                                <a href="<?php echo e(route('roles.edit', $role->id)); ?>" class="text-success mr-2">
                                                    <i class="nav-icon i-Pen-2 font-weight-bold fs-16"></i>
                                                </a>
                                                <a onclick="remove(<?php echo e($role->id); ?>,'roles')" class="text-danger mr-2">
                                                    <i class="nav-icon i-Close-Window font-weight-bold fs-16"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>


                    </div>
                </div>
            </div>
            <!-- end of col-->


        </div>
        <!-- end of row -->
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

    <script type="text/javascript">
         function editRole(event) {
            var id = $(event).data("id");
            let _url = `roles/${id}`;
            $('#roleError').text('');


            $.ajax({
                url: _url,
                type: "GET",
                success: function(response) {
                    if (response) {
                        $("#role_id").val(response.id);
                        $("#role").val(response.role);
                        $('#role-modal').modal('show');
                    }
                }
            });
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/adoxamuf/public_html/apps/bloomax/resources/views/backend/role/index.blade.php ENDPATH**/ ?>