


<?php $__env->startSection('main-content'); ?>
    <div class="col-md-12 mb-4">
        <div class="breadcrumb">
            <h1>Add New Product</h1>
        </div>
        <div class="basic-input-groups">
            <div class="container-fluid">
                <div class="row">
                    <form action="<?php echo e(route('product.store')); ?>" name="product_form" method="POST"
                        class="needs-validation was-validated">
                        <?php echo csrf_field(); ?>
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-lg-7 mb-3">
                                    <div class="card">
                                        <div class="card-header bg-transparent">
                                            <h3 class="card-title">Product Information</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="form-row col-md-12">
                                                <div class="form-group col-md-6">
                                                    <label for="inputEmail1" class="ul-form__label fs-16">Product
                                                        Name:</label>
                                                    <input type="text" class="form-control" id="name" name="name"
                                                        placeholder="Enter product name" required>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="inputEmail2" class="ul-form__label fs-16">Category:</label>
                                                    <select class="selectpicker form-control show-tick"
                                                        data-style="btn-primary-outline" name="category_id"
                                                        data-live-search="true">
                                                        <option disabled>Select Category</option>
                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option name="category_id" value="<?php echo e($category->id); ?>">
                                                                <?php echo e($category->name); ?>

                                                            </option>
                                                            <?php $__currentLoopData = $category->childrenCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($childCategory->id); ?>">
                                                                    <?php echo e('--' . $childCategory->name); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-row col-md-12">
                                                <div class="form-group col-md-6">
                                                    <label for="inputEmail2" class="ul-form__label fs-16">Brand:</label>
                                                    <select class="selectpicker form-control show-tick"
                                                        data-style="btn-primary-outline" name="brand_id"
                                                        data-live-search="true" required>
                                                        <option disabled>Select Brand</option>
                                                        <?php $__currentLoopData = App\Models\Brand::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="inputEmail2" class="ul-form__label fs-16">Unit:</label>
                                                    <select class="selectpicker form-control show-tick"
                                                        data-style="btn-primary-outline" name="unit_id"
                                                        data-live-search="true" required>
                                                        <option disabled>Select Unit</option>
                                                        <?php $__currentLoopData = App\Models\Unit::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->short_name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label for="inputEmail1" class="ul-form__label fs-16">Product
                                                    Description:</label>
                                                <textarea class="form-control" aria-label="With textarea"
                                                    name="description"></textarea>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header bg-transparent">
                                            <h3 class="card-title">Product Images</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="form-group col-md-12">
                                                <label for="inputEmail2" class="ul-form__label fs-16">Gallery
                                                    Images:</label>
                                                <div class="input-group mb-3" data-toggle="emdadUploader" data-type="image">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text"
                                                            id="inputGroupFileAddon01">Upload</span>
                                                    </div>
                                                    <div class="custom-file">
                                                        <input class="custom-file-input" data-type="single" name="photos"
                                                            id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
                                                        <label class="custom-file-label" for="inputGroupFile01">Choose
                                                            file</label>
                                                    </div>
                                                </div>
                                                <div class="selected_files_preview d-flex" for="inputGroupFile01">

                                                </div>
                                                <small id="passwordHelpBlock" class="ul-form__text form-text ">
                                                    These images are visible in product details page gallery. Use 600x600
                                                    sizes
                                                    images.
                                                </small>
                                                <div class="" id="file_holder"></div>
                                            </div>
                                            
                                        </div>
                                    </div>

                                    <div class="card">
                                        <div class="card-header bg-transparent">
                                            <h3 class="card-title">Product price + stock</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="form-row col-md-12">
                                                <div class="form-group col-md-6">
                                                    <label for="inputEmail1" class="ul-form__label">Unit Price:</label>
                                                    <input type="text" class="form-control" name="unit_price"
                                                        id="unit_price" placeholder="0" required>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="inputEmail2" class="ul-form__label">Quantity:</label>
                                                    <input type="text" class="form-control" name="current_stock"
                                                        id="current_Stock" placeholder="0" required>

                                                </div>
                                            </div>
                                            <div class="form-row col-md-12">
                                                <div class="form-group col-md-6">
                                                    <label for="inputEmail1" class="ul-form__label">Discount Date
                                                        Range:</label>
                                                    <input type="text" placeholder="Pick Discount Date Range"
                                                        class="form-control" name="datefilter" value="" />
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="inputEmail1" class="ul-form__label">SKU:</label>
                                                    <input type="text" class="form-control" name="barcode" id="barcode"
                                                        placeholder="SKU">
                                                </div>
                                            </div>
                                            <div class="form-row col-md-12">
                                                <div class="form-group col-md-8">
                                                    <label for="inputEmail1" class="ul-form__label">Discount:</label>
                                                    <input type="text" class="form-control" id="discount" name="discount"
                                                        value="0" required>
                                                </div>
                                                <div class="form-group col-md-4" style="margin: auto;">
                                                    <label for="inputEmail1" class="ul-form__label"></label>
                                                    <select class="selectpicker form-control show-tick"
                                                        data-style="btn-primary-outline" name="discount_type"
                                                        data-live-search="true">
                                                        <option value="Flat">Flat</option>
                                                        <option value="Percent">Percent</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-5 mb-3">
                                    <div class="card">
                                        <div class="card-header bg-transparent">
                                            <h3 class="card-title">Estimate Shipping Time</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="form-group col-md-12">

                                                <label for="inputEmail4" class="ul-form__label">Shipping Days:</label>
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" name="est_shipping_days"
                                                        aria-label="Recipient's username" aria-describedby="basic-addon2">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text" id="basic-addon2">Days</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header bg-transparent">
                                            <h3 class="card-title">Low Stock Quantity Warning</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="form-group col-md-12">
                                                <label for="inputEmail4" class="ul-form__label">Quantity:</label>
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" value="1"
                                                        name="low_stock_quantity" aria-label="Recipient's username"
                                                        aria-describedby="basic-addon2">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text" id="basic-addon2">Nos</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header bg-transparent">
                                            <h3 class="card-title">Cash On Delivery</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="form-row">
                                                <div class="col-md-6" style="text-align: center">
                                                    <label class="ul-form__label">Status</label>
                                                </div>
                                                <div class="col-md-6" style="margin: auto;">
                                                    <label class="switch switch-success mr-3">

                                                        <input type="checkbox" checked="" name="cash_on_delivery" value="1">
                                                        <span class="slider"></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header bg-transparent">
                                            <h3 class="card-title">VAT & Tax</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="form-row col-md-12">
                                                <div class="form-group col-md-8">
                                                    <label for="inputEmail1" class="ul-form__label">Tax:</label>
                                                    <input type="text" class="form-control" name="tax" id="inputEmail1"
                                                        value="0" required>
                                                </div>
                                                <div class="form-group col-md-4" style="margin: auto;">
                                                    <label for="inputEmail1" class="ul-form__label"></label>
                                                    <select class="selectpicker form-control show-tick"
                                                        data-style="btn-primary-outline" name="tax_type"
                                                        data-live-search="true">
                                                        <option value="Flat">Flat</option>
                                                        <option value="Percent">Percent</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header bg-transparent">
                                            <h3 class="card-title">Product Variation</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="form-group row col-md-12">
                                                <div class="col-md-4">
                                                    <label for="inputEmail2" class="ul-form__label fs-16">Colors:</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <select class="selectpicker form-group show-tick"
                                                        data-style="btn-primary-outline" name="colors[]" id="color" multiple
                                                        data-live-search="true" data-width="">

                                                        <?php $__currentLoopData = \App\Models\Color::orderBy('name', 'asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($color->id); ?>" style="color: #000"
                                                                data-content="<i class='bi bi-bookmark-fill' style='color:<?php echo e($color->code); ?>'></i> <?php echo e($color->name); ?>">

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group row col-md-12">
                                                <div class="col-md-4">
                                                    <label for="inputEmail2" class="ul-form__label fs-16">Product
                                                        Type:</label>
                                                </div>
                                                <div class="col-md-8 form-group">
                                                    <select class="selectpicker form-group show-tick"
                                                        data-style="btn-primary-outline" name="product_type"
                                                        id="product_type" data-live-search="true" data-width="">
                                                        <option value="single">Single</option>
                                                        <option value="single">Multiple</option>
                                                    </select>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-12">
                                <div class="card-footer">
                                    <div class="mc-footer">
                                        <div class="row">
                                            <div class="col-lg-12 text-right">
                                                <button type="button" class="btn btn-secondary btn-xl m-1">Cancel</button>
                                                <button type="submit" name="save" value="save"
                                                    class="btn btn-success btn-xl m-1">Save</button>
                                                <button type="submit" name="variable" value="variable"
                                                    class="btn btn-success btn-xl m-1">Save & Add as Varaible</button>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
    <?php echo $__env->make('backend.product.products.product_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Emdad\resources\views/backend/product/products/create.blade.php ENDPATH**/ ?>