
<?php $__env->startSection('main-content'); ?>
    <div class="col-md-12 mb-4">
        <div class="card text-left">
            <div class="card-body">
                <h4 class="mb-3 fs-22 font-weight-bold">Product List
                    <div style="float: right"><a type="button" class="btn btn-primary ripple m-1" href="<?php echo e(route('product.create')); ?>">
                            New Product</a></div>
                </h4>
                <p class="fs-16">All Your Products</p>
                <div class="table-responsive">
                    <div id="comma_decimal_table_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">

                        <div class="row">
                            <div class="col-sm-12">
                                <table id="product_datatable" class="display table table-striped table-bordered dataTable"
                                    style="width: 100%;" role="grid" aria-describedby="comma_decimal_table_info">
                                    <thead>
                                        <tr role="row">
                                            <th class="sorting_asc" tabindex="0" aria-controls="product_datatable"
                                                rowspan="1" colspan="1" aria-sort="ascending"
                                                aria-label="Name: activate to sort column descending"
                                                style="width: 90.002px;">Id</th>
                                            <th class="sorting_asc" tabindex="0" aria-controls="product_datatable"
                                                rowspan="1" colspan="1" aria-sort="ascending"
                                                aria-label="Name: activate to sort column descending"
                                                style="width: 181.002px;">Image</th>
                                            <th class="sorting_asc" tabindex="0" aria-controls="product_datatable"
                                                rowspan="1" colspan="1" aria-sort="ascending"
                                                aria-label="Name: activate to sort column descending"
                                                style="width: 181.002px;">Name</th>
                                            <th class="sorting" tabindex="0" aria-controls="product_datatable"
                                                rowspan="1" colspan="1"
                                                aria-label="Position: activate to sort column ascending"
                                                style="width: 270.002px;">Category</th>
                                            <th class="sorting" tabindex="0" aria-controls="product_datatable"
                                                rowspan="1" colspan="1"
                                                aria-label="Position: activate to sort column ascending"
                                                style="width: 270.002px;">Brand</th>
                                            <th class="sorting" tabindex="0" aria-controls="product_datatable"
                                                rowspan="1" colspan="1"
                                                aria-label="Position: activate to sort column ascending"
                                                style="width: 270.002px;">Actions</th>

                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>

                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
    <script type="text/javascript">
        $('document').ready(function() {

            // csrf token
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            //Datatable
            $('#product_datatable').DataTable({
                processing: true,
                serverSide: true,
                type: "POST",
                ajax: "<?php echo e(route('product.index')); ?>",
                columns: [

                    {
                        data: 'id',
                        name: 'id'
                    },

                    {
                        data: 'image',
                        name: 'image',
                        render: function(data, type, full, meta) {
                            return '<a href=' + data + '  target="_blank"><img src=' + data +
                                ' border="0" width="80" class="img-rounded" align="center" /></a>';
                        }
                    },
                    {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'Category',
                        name: 'Category'
                    },
                    {
                        data: 'Brand',
                        name: 'Brand'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false
                    },
                ]
            });


        });

        

        //Product Deletion
        function delete_product(id) {
            var url = 'product';
            remove(id, url);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Emdad\resources\views/backend/product/products/index.blade.php ENDPATH**/ ?>