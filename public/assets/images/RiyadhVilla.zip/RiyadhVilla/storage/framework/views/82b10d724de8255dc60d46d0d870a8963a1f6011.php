<script>
    $('document').ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

    });

    function get_attributes() {
        var attribute = [];
        let obj = {};
        $.each($("#attribute option:selected"), function() {
            obj[this.value] = this.text;
        });
        return obj;
    }

    $('select#attribute').on('change', function(e) {
        let obj = '';
        $('.customer_choice_options').html('');
        obj = get_attributes();
        //  console.log(obj);
        if (obj.length < 1) {
            $('#generate_btn').prop('disabled', true);
        }
        $.each(obj, function(key, value) {
            // console.log(key, value);

            $.ajax({
                url: "get_attribute_values",
                type: 'GET',
                dataType: 'json',
                data: {
                    id: key
                },
                success: function(res) {
                    //  console.log(res);
                    var all_attributeValues = res.attribute_values;
                    // console.log(all_attributeValues);
                    var attr_values;
                    var html;
                    html = ' <div class="form-group row">' +

                        '<div class="col-md-4">' +
                        '<input type="button" class="btn  btn-light-outline m-1"  style="font-weight: 600;font-size: 18px !important;" value="' +
                        value + '">' +
                        '</div>' +
                        '<div class="col-md-6">' +
                        '<div class="ul-form__radio-inline">' + res +
                        '</div>' +
                        '</div></div>';
                    $('#generate_btn').prop('disabled', false);
                    $('.customer_choice_options').append(html);

                }
            });
        });



    });

    function make_combination_ids() {
        let obj = {};
        var attributes = get_attributes();
        var attribute_id;
        $.each(attributes, function(keyName, keyValue) {
            // console.log(keyName + ': ' + keyValue);
            var arr_values = [];
            $("input:checkbox[name='attr_values']:checked").each(function() {

                if (keyName == $(this).attr('data-attribute')) {
                    arr_values.push($(this).val());

                }
            });
            obj[keyName] = arr_values;
        });
        return obj;
    }

    function make_combination() {
        let combination_ids = '';
        let args;
        combination_ids = make_combination_ids();
        args = Object.values(combination_ids);

        //console.log(args);

        var r = [],
            max = args.length - 1;

        function helper(arr, i) {
            for (var j = 0, l = args[i].length; j < l; j++) {
                var a = arr.slice(0); // clone arr
                a.push(args[i][j]);
                if (i == max)
                    r.push(a);
                else
                    helper(a, i + 1);
            }
        }
        helper([], 0);

        //console.log(r);

        $.ajax({
            url: "<?php echo e(route('ProductVariation.create')); ?>",
            type: 'GET',
            dataType: 'json',
            data: {
                combination_ids: r
            },
            success: function(res) {
                //  console.log(res);


                let html = '';
                let j=0;
                res.forEach(function(items) {
                    // console.log(item);
                    let ids = [];
                    let names = '';
                    items.forEach(function(item) {
                        // console.log(item.id);
                        ids.push(item.id);
                        names += item.name + ' ';

                    });

                    html +=
                        '<tr><td><input class="form-control" type="text" name="name[]" id="name" value="' +
                        names + '" readonly><input name="variation_ids[]" value="' + ids +
                        '" type="hidden" ></td><td><input class="form-control" type="text" value="0" name="price[]" id="price[]"></td><td><input class="form-control" type="text" name="barcode[]" id="barcode"></td><td><input class="form-control" type="text" value="0" name="quantity[]" id="current_Stock"></td><td><div class="input-group mb-3" data-toggle="emdadUploader" data-type="image"><div class="custom-file"><input class="custom-file-input" data-type="multiple" name="photos[]" id="inputGroupFile'+j+'" aria-describedby="inputGroupFileAddon'+j+'"><label class="custom-file-label" for="inputGroupFile'+j+'">Choose file</label></div></div><div class="selected_files_preview d-flex" for="inputGroupFile'+j+'"></td></tr></div>';

           j++;     });

                $('tbody#varitation_combination').html(html);
            }
        });
    }
</script>
<?php /**PATH C:\xampp\htdocs\Emdad\resources\views/backend/product/products/product_js.blade.php ENDPATH**/ ?>