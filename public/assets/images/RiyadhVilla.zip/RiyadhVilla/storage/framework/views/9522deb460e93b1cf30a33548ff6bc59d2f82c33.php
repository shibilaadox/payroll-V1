

<?php $__env->startSection('main-content'); ?>
    <div class="breadcrumb">
        <h1>Create Staffs</h1>
    </div>
    <div class="separator-breadcrumb border-top"></div>
    <section class="basic-action-bar">
        <div class="row mb-8">
            <div class="col-lg-2"></div>
            <div class="col-lg-8 mb-3">
                <!--begin::form 2-->
                <form action="<?php echo e(route('staff.store')); ?>" method="POST" class="needs-validation was-validated">
                    <?php echo csrf_field(); ?>
                    <!-- start card  Horizontal Form Layout-->
                    <div class="card ul-card__margin-20">
                        <div class="card-header bg-transparent">
                            <h3 class="card-title">Staff Information</h3>
                        </div>

                        <div class="card-body">
                            <div class="form-group row">
                                <label for="staticName" class="action-bar-horizontal-label col-lg-4 col-form-label ">Full
                                    Name:</label>
                                <div class="col-lg-6 mb-4">
                                    <input type="text" class="form-control" id="staticName" placeholder="Enter full name"
                                        name="name" required>

                                </div>
                                <label for="staticEmail" class="action-bar-horizontal-label col-lg-4 col-form-label ">Email
                                </label>
                                <div class="col-lg-6  mb-4">
                                    <input type="text" class="form-control" name="email" id="staticEmail"
                                        placeholder="Enter Email" required>

                                </div>
                                <label for="staticPhone" class="action-bar-horizontal-label col-lg-4 col-form-label ">Phone
                                </label>
                                <div class="col-lg-6  mb-4">
                                    <input type="text" class="form-control" name="phone" id="staticPhone"
                                        placeholder="Enter Phone number" required>

                                </div>
                                <label for="staticPassword"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label ">Password </label>
                                <div class="col-lg-6  mb-4">
                                    <input type="text" class="form-control" id="staticPassword"
                                        placeholder="Enter Password" required >

                                </div>

                                <label for="staticRole"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label">Role:</label>
                                <div class="col-lg-6  mb-4">
                                    <select class="form-control" name="role_name">
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option required>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>



                        </div>
                        <div class="card-footer">
                            <div class="mc-footer">
                                <div class="row text-right">
                                    <div class="col-lg-4"></div>
                                    <div class="col-lg-6 text-left">
                                        <button type="submit"  class="btn btn-primary m-1">Save</button>
                                        <button type="button" class="btn btn-outline-secondary m-1">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end card  Horizontal Form Layout-->
                </form>
                <!-- end::form 2-->
            </div>
            <div class="col-lg-3"></div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Finance\resources\views/backend/staff/staffs/create.blade.php ENDPATH**/ ?>