

<?php $__env->startSection('main-content'); ?>
    <div class="breadcrumb">
        <h1>Create Staffs</h1>
    </div>
    <div class="separator-breadcrumb border-top"></div>
    <section class="basic-action-bar">
        <div class="row mb-8">
            <div class="col-lg-2"></div>
            <div class="col-lg-8 mb-3">
                <!--begin::form 2-->
                <form action="<?php echo e(route('users.store')); ?>" method="POST" class="needs-validation was-validated">
                    <?php echo csrf_field(); ?>
                    <!-- start card  Horizontal Form Layout-->
                    <div class="card ul-card__margin-20">
                        <div class="card-header bg-transparent">
                            <h3 class="card-title">User Information</h3>
                        </div>

                        <div class="card-body">
                            <div class="form-group row">
                                <label for="staticName" class="action-bar-horizontal-label col-lg-4 col-form-label ">Full
                                    Name:</label>
                                <div class="col-lg-6 mb-4">
                                    <input type="text" class="form-control" id="staticName" placeholder="Enter full name"
                                        name="name" required>

                                </div>
                                <label for="staticEmail" class="action-bar-horizontal-label col-lg-4 col-form-label ">Email
                                </label>
                                <div class="col-lg-6  mb-4">
                                    <input type="text" class="form-control" name="email" id="staticEmail"
                                        placeholder="Enter Email" required>

                                </div>
                                <label for="staticPhone" class="action-bar-horizontal-label col-lg-4 col-form-label ">Phone
                                </label>
                                <div class="col-lg-6  mb-4">
                                    <input type="text" class="form-control" name="phone" id="staticPhone"
                                        placeholder="Enter Phone number" required>

                                </div>
                                <label for="staticPassword"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label ">Password </label>
                                <div class="col-lg-6  mb-4">
                                    <input type="text" class="form-control" id="staticPassword"
                                        placeholder="Enter Password" required >

                                </div>

                                <label for="staticRole"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label">Role:</label>
                                <div class="col-lg-6  mb-4">
                                    <select class="form-control" name="role_name" id="role_name">
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option required>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                               
                                <label for="staticDepartment" style="display: none;" 
                                    class="action-bar-horizontal-label col-lg-4 col-form-label" id="label_department">Department:</label>
                                <div class="col-lg-6  mb-4" style="display: none;" id="div_department">
                                    <select class="form-control" name="department_name" id="department_name">
                                        <option value="">select a department</option>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option required>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                               

                               
                                <label for="staticLocation" style="display: none;" id="label_location"
                                    class="action-bar-horizontal-label col-lg-4 col-form-label">Location:</label>
                                <div class="col-lg-6  mb-4" style="display: none;" id="div_location">

                                    <select class="form-control" name="location_name" id="location_name">
                                        <option value="">select a location</option>
                                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($location->id); ?>"><?php echo e($location->location_name); ?></option required>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                               
                            </div>



                        </div>
                        <div class="card-footer">
                            <div class="mc-footer">
                                <div class="row text-right">
                                    <div class="col-lg-4"></div>
                                    <div class="col-lg-6 text-left">
                                        <button type="submit"  class="btn btn-primary m-1">Save</button>
                                        <button type="button" class="btn btn-outline-secondary m-1">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end card  Horizontal Form Layout-->
                </form>
                <!-- end::form 2-->
            </div>
            <div class="col-lg-3"></div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>


<script type="text/javascript">
    
    $("#role_name").change(function(){

        if($("#role_name").val()=="Employee")
        {
            $("#label_department").show();
            $("#div_department").show();
            $("#label_location").show();
            $("#div_location").show();
        }

        else
        {
            $("#label_department").hide();
            $("#div_department").hide();
            $("#label_location").hide();
            $("#div_location").hide();    
        }

    });
    

</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Finance\resources\views/backend/users/create.blade.php ENDPATH**/ ?>