<!-- header start -->
<header class=" main-header bg-white d-flex justify-content-between p-2">
    <div class="logo">
        <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="" style="height:auto;width:75%;">
    </div>

    <div class="header-toggle">
        <div class="menu-toggle mobile-menu-icon">
            <div></div>
            <div></div>
            <div>
            </div>
        </div>
       

    </div>
    <div class="header-part-right">
        <!-- Full screen toggle -->
        <i class="i-Full-Screen header-icon d-none d-sm-inline-block" data-fullscreen=""></i>
              <!-- User avatar dropdown -->
              <div class="dropdown">
                <div class="user col align-self-end">
                    <img src="<?php echo e(asset('assets/images/faces/1.jpg')); ?>" id="userDropdown" alt="" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
    
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <i class="i-Lock-User mr-1"></i> <?php echo e(auth()->user()->name); ?>

                        </div>
                       
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></a><form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo csrf_field(); ?></form>
                        
                    </div>
                </div>
            </div>
        
        
</header>
<!-- header close --><?php /**PATH /home2/adoxamuf/public_html/apps/bloomax/resources/views/layouts/large-vertical-sidebar/header.blade.php ENDPATH**/ ?>